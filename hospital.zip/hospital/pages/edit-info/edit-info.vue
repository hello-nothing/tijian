<template>
	<view class="phone-content">
		<form @submit="submit">
			<view class="title">预约人姓名：</view>
			<view class="phone"><input v-model="formParam.name" class="phone-input" name="name" maxlength="13" type="text" value="" /></view>
			<view class="title">预约人年龄：</view>
			<view class="phone"><input v-model="formParam.age" class="phone-input" name="age" maxlength="3" type="number" value="" /></view>
			<view class="title">预约人性别：</view>
			<view class="phone">
				<radio-group name="sex">
					<label>
						<radio value="male" />
						<text>男</text>
					</label>
					<label class="sex-tip">
						<radio value="female" />
						<text>女</text>
					</label>
				</radio-group>
			</view>
			<view class="title">预约人手机号：</view>
			<view class="phone">
				<input disabled="disabled" placeholder="注册时所填手机号" v-model="formParam.phoneNumber" class="phone-input" name="phoneNumber" maxlength="11" type="number" value="" />
			</view>
			<view class="title">预约人身份证号：</view>
			<view class="phone"><input v-model="formParam.idcard" class="phone-input" name="idcard" maxlength="30" type="number" value="" /></view>
			<view class="title">婚否：</view>
			<view class="phone">
				<radio-group name="merry">
					<label>
						<radio value="hadMerry" />
						<text>已婚</text>
					</label>
					<label class="sex-tip">
						<radio value="noMerry" />
						<text>未婚</text>
					</label>
				</radio-group>
			</view>
			<button class="confirm" form-type="submit" type="primary">确认修改</button>
		</form>
	</view>
</template>

<script>
import { mapState, mapMutations } from 'vuex';
import apiservice from '../../static/js/request.js';
import uniCalendar from '@/components/uni-calendar/uni-calendar.vue';
export default {
	data() {
		return {
			formParam: {
				name: '',
				age: '',
				phoneNumber: '',
				idcard: '',
				sex: '',
				merry: ''
			},
			hadMerry: true
		};
	},
	components: {
		uniCalendar
	},
	computed: {
		...mapState(['hasLogin', 'forcedLogin'])
	},
	methods: {
		// 编辑预约信息
		submit: function(e) {
			console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value));
			var formdata = e.detail.value;
			var info = JSON.stringify(e.detail.value);
			console.log(info);
			let opts = {
				url: '/login/authentication',
				method: 'POST'
			};
			let params = info;
			apiservice.httpRequest(opts, params).then(
				res => {
					console.log('修改返回信息', res);
					if (res.data.flag === true) {
						uni.showToast({
							title: '修改成功',
							icon: 'success',
							duration: 3000
						});
						uni.setStorageSync('yuyueinfo', JSON.stringify(e.detail.value)); // 缓存预约信息
						uni.navigateBack({
							delta: 1
						});
					} else {
						console.log('error');
						uni.showToast({
							title: '此手机号不是会员，请先注册',
							duration: 2000
						});
					}
				},
				error => {
					console.log(error);
				}
			);
		},
		change(e) {
			console.log(e);
		}
	},
	onLoad() {
		if (!this.hasLogin) {
			uni.showModal({
				title: '未登录',
				content: '您未登录，需要登录后才能继续',
				showCancel: false,
				success: res => {
					if (res.confirm) {
						if (this.forcedLogin) {
							uni.reLaunch({
								url: '../login/login'
							});
						}
					}
				}
			});
		}
		if (uni.getStorageSync('yuyueinfo')) {
			const formParam = JSON.parse(uni.getStorageSync('yuyueinfo'));
			console.log(formParam);
			this.formParam = formParam;
		}
		if (uni.getStorageSync('phone')) {
			const formParam = JSON.parse(uni.getStorageSync('phone'));
			this.formParam.phoneNumber = formParam;
		}
	}
};
</script>

<style lang="scss">
page {
	background-color: #efeff4;
}

.phone-content {
	position: relative;
	// width: 100%;
	padding: 30rpx 20rpx;
	padding-bottom: 0;
}

.title {
	margin-bottom: 20rpx;
	font-size: 34rpx;
}

.phone {
	height: 80rpx;
	line-height: 80rpx;
	padding: 0 20rpx;
	margin-bottom: 30rpx;
	border-radius: 8rpx;
	background-color: #fff;
	border: 1rpx solid #8f8f94;
}

.phone-input {
	height: 80rpx;
	line-height: 80rpx;
}

.confirm {
	position: fixed;
	bottom: 0;
	width: calc(100% - 40rpx);
	margin-top: 100rpx;
}

.sex-tip {
	margin-left: 100rpx;
}
</style>
