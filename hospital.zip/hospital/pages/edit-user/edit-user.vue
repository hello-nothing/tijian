<template>
	<view class="user-content">
		<view class="container">
			<!-- <view class="model-info clearfix">
				<view class="title pull-left">头像</view>
				<view class="pull-right"><image class="image-size" src="" mode=""></image></view>
				<view class="a-tips pull-right">>></view>
			</view> -->
			<!-- <view class="model-info clearfix">
				<view class="title pull-left">用户名</view>
				<view class="title-after pull-left">{{userName}}</view>
				<view class="a-tips pull-right">></view>
			</view> -->
			<navigator class="model-info clearfix" url="../phone/phone">
				<view class="title pull-left">绑定手机号</view>
				<view class="title-after pull-left">{{ userPhone }}</view>
				<view class="a-tips pull-right">></view>
			</navigator>
			<navigator class="model-info clearfix" url="../password/password">
				<view class="title pull-left">修改密码</view>
				<!-- <view class="pull-right"></view> -->
				<view class="a-tips pull-right">></view>
			</navigator>
		</view>
	</view>
</template>

<script>
	
import apiservice from '../../static/js/request.js';
export default {
	data() {
		return {
			userName: '手机用户',
			userPhone: ''
		};
	},
	methods: {},
	onShow() {
		if (uni.getStorageSync('phone')) {
			const formParam = JSON.parse(uni.getStorageSync('phone')); // 获取缓存数据
			this.userPhone = formParam.phone;
		}
	},
	onLoad() {
		if (uni.getStorageSync('phone')) {
			const formParam = JSON.parse(uni.getStorageSync('phone')); // 获取缓存数据
			this.userPhone = formParam.phone;
		}
	}
};
</script>

<style lang="scss">
page {
	background-color: #efeff4;
}
.user-content {
	width: 100%;
	padding-top: 30rpx;
}
.container {
	padding: 0 15rpx;
	background-color: #fff;
}
.model-info {
	height: 100rpx;
	border-bottom: 1rpx solid #dddddd;
	.title {
		width: 40%;
		font-size: 36rpx;
		line-height: 100rpx;
	}
	.a-tips {
		line-height: 100rpx;
	}
}
.image-size {
	width: 100rpx;
	height: 100rpx;
}
.title-after {
	width: 55%;
	height: 100rpx;
	text-align: right;
	line-height: 100rpx;
}
</style>
