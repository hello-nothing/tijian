<template>
	<view class="list-detail">
		<view class="model-before">
			<view class="title-model">
				<view class="title">套餐名称：</view>
				<view class="title">{{ title }}</view>
			</view>
			<view class="title-model">
				<view class="title">套餐价格：</view>
				<view class="detail">¥{{ price }}</view>
			</view>
			<view class="title-model">
				<view class="title">适合年龄：</view>
				<view class="detail">{{ age }}岁</view>
			</view>
			<view class="title-model">
				<view class="title">套餐介绍：</view>
				<view class="detail">{{ introduce }}</view>
			</view>
			<view class="title-model">
				<view class="title">套餐检测项目：</view>
				<view class="detail" v-for="(item, index) in checkDetail" :key="index">{{ item }}</view>
			</view>
			<!-- <view class="title-model">
				<view class="title">检测注意事项：</view>
				<view class="detail">{{ checkNotice }}</view>
			</view> -->
		</view>
		<view @click="goCheck(id)" class="button-meet" url="../yuyue-confirm/yuyue-confirm">立即预约</view>
	</view>
</template>

<script>
	import apiservice from '../../static/js/request.js';
	export default {
		data() {
			return {
				title: '',
				price: '',
				age: '',
				introduce: '',
				checkNotice: '上午十点之前空腹采集，采集后立即。。。',
				id: '',
				checkDetail: []
			};
		},

		methods: {
			// 立即预约
			goCheck: function(id) {
				console.log(id);
				uni.navigateTo({
					url: '../yuyue-confirm/yuyue-confirm?id=' + id
				});
			},
			// 获取套餐详情信息
			getdetail: function() {
				let opts = {
					url: '/setmeal/findById',
					method: 'get'
				};
				let params = {
					id: this.id
				};
				apiservice.httpRequest(opts, params).then(
					res => {
						console.log('套餐详情信息', res);
						if (res.data.flag === true) {
							this.title = res.data.data.name;
							this.price = res.data.data.price;
							this.age = res.data.data.age;
							this.introduce = res.data.data.remark;
							console.log(res.data.data.checkGroups);
							const checklist = res.data.data.checkGroups;
							checklist.forEach(item => {
								this.checkDetail.push(item.name);
							});
							console.log(this.checkDetail);
						} else {
							console.log('error');
						}
					},
					error => {
						console.log(error);
					}
				);
			}
		},
		onLoad: function(option) {
			console.log(option);
			this.id = option.id;
			this.getdetail();
		}
	};
</script>

<style lang="scss">
	page {
		background-color: #efeff4;
	}

	.list-detail {
		position: relative;
		width: 100%;
		background-color: #efeff4;
	}

	.model-before {
		padding: 20rpx;
	}

	.title-model {
		// height: 100rpx;
		padding: 20rpx;
		margin-bottom: 20rpx;
		background-color: #fff;
		border-radius: 8rpx;
	}

	.title {
		font-size: 36rpx;
		font-weight: bold;
	}

	.detail {
		padding-top: 20rpx;
		font-size: 32rpx;
	}

	.button-meet {
		position: fixed;
		bottom: 0;
		width: 100%;
		height: 100rpx;
		text-align: center;
		line-height: 100rpx;
		background-color: #0faeff;
	}
</style>
