<template>
	<view class="main-content">
		<!-- <view v-if="hasLogin" class="hello">
			<view class="title">您好 {{ userName }}，您已成功登录。</view>
			<view class="ul">
				<view>这是 uni-app 带登录模板的示例App首页。</view>
				<view>在 “我的” 中点击 “退出” 可以 “注销当前账户”</view>
			</view>
		</view> -->
		<view class="list-content">
			<view @click="goDetail(item.id)" class="every-list clearfix" v-for="(item, index) in listData" :key="index">
				<view class="list-name pull-left">{{ item.name }}</view>
				<view class="look-list pull-right">查看详情>></view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mapState
	} from 'vuex';

	import apiservice from '../../static/js/request.js';
	export default {
		data() {
			return {
				listData: [{
						name: '入职无忧体检套餐（男女通用）'
					},
					{
						name: '粉红珍爱(女)升级TM12项筛查体检套餐'
					},
				],
			};
		},
		computed: mapState(['forcedLogin', 'hasLogin', 'userName']),
		methods: {
			// 跳转至详情页面
			goDetail(id) {
				console.log(id)
				uni.navigateTo({
					url: '../list-detail/list-detail?id=' + id
				});
			},
			// 获取套餐列表
			getchecklist: function() {
				let opts = {
					url: '/setmeal/getSetmeal',
					method: 'get'
				};
				apiservice.httpRequest(opts).then(
					res => {
						console.log('套餐列表数据', res)
						this.listData = res.data.data;
					},
					error => {
						console.log(error);
					}
				);
			}
		},
		onLoad() {
			this.getchecklist();
			console.log(this.hasLogin);
			if (!this.hasLogin) {
				uni.showModal({
					title: '未登录',
					content: '您未登录，需要登录后才能继续',
					showCancel: false,
					success: res => {
						if (res.confirm) {
							/**
							 * 如果需要强制登录，使用reLaunch方式
							 */
							if (this.forcedLogin) {
								uni.reLaunch({
									url: '../login/login'
								});
							} else {
								uni.navigateTo({
									url: '../login/login'
								});
							}
						}
					}
				});
			}
		}
	};
</script>

<style>
	page {
		/* width: 100%; */
		background-color: #f5f5f5;
	}

	.main-content {
		/* width: 335px; */
		padding: 20rpx;
	}

	.hello {
		display: flex;
		flex: 1;
		flex-direction: column;
	}

	.title {
		color: #8f8f94;
		margin-top: 25px;
	}

	.ul {
		font-size: 15px;
		color: #8f8f94;
		margin-top: 25px;
	}

	.ul>view {
		line-height: 25px;
	}

	.every-list {
		/* width: 100%; */
		height: 100rpx;
		padding: 0 20rpx;
		margin-bottom: 20rpx;
		line-height: 100rpx;
		background-color: #ffffff;
		border-radius: 8rpx;
		font-size: 36rpx;
	}

	.list-name {
		width: 60%;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
</style>
