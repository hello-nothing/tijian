<template>
	<view class="phone-content">
		<form @submit="submit">
			<view class="title">输入手机号：</view>
			<view class="phone"><input disabled="disabled" v-model="oldphone" class="phone-input" name="phone" maxlength="11" type="number" value="" /></view>
			<view class="title">输入新密码：</view>
			<view class="phone"><input class="phone-input" name="password" maxlength="13" type="text" value="" /></view>
			<button class="confirm" form-type="submit" type="primary">确认修改</button>
		</form>
	</view>
</template>

<script>

import apiservice from '../../static/js/request.js';
export default {
	data() {
		return {
			oldphone: ''
		};
	},
	onLoad() {
		const value = uni.getStorageSync('phone');
		if(value) {
			this.oldphone = value;
			console.log(this.oldphone)
		}
	},
	methods: {
		// 修改密码
		submit: function(e) {
			console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value));
			var formdata = e.detail.value;
			var info = JSON.stringify(e.detail.value);
			if(e.detail.value.phone!== this.oldphone) {
				uni.showToast({
					title: '手机号输入错误',
					duration:3000
				});
			}
			let opts = {
				url: '/login/updatePassword',
				method: 'GET'
			};
			let params = {
				phone: e.detail.value.phone,
				password: e.detail.value.password,
			};
			apiservice.httpRequest(opts, params).then(
				res => {
					console.log(res)
					// this.doneList = res.data
					if (res.data.flag === true) {
						uni.showToast({
							title: '修改成功',
						});
						uni.setStorageSync('password', JSON.stringify(e.detail.value));
						uni.navigateTo({
						    url: '../login/login'
						});
					} else {
						uni.showToast({
							title: '修改失败'
						});
					}
				},
				error => {
					console.log(error);
				}
			);

		}
	}
};
</script>

<style lang="scss">
page {
	background-color: #efeff4;
}
.phone-content {
	width: 100%;
	padding: 30rpx 20rpx;
}
.title {
	margin-bottom: 20rpx;
	font-size: 34rpx;
}
.phone {
	height: 80rpx;
	line-height: 80rpx;
	padding: 0 20rpx;
	margin-bottom: 30rpx;
	border-radius: 8rpx;
	background-color: #fff;
	border: 1rpx solid #8f8f94;
}
.phone-input {
	height: 80rpx;
	line-height: 80rpx;
}
.confirm {
	margin-top: 100rpx;
}
</style>
