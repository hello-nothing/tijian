<template>
	<view class="phone-content">
		<form @submit="submit">
			<view class="title">输入旧手机号：</view>
			<view class="phone"><input disabled="disabled" v-model="phone" class="phone-input" name="oldphone" maxlength="11" type="number" value="" /></view>
			<view class="title">输入新手机号：</view>
			<view class="phone"><input class="phone-input" name="newphone" maxlength="11" type="number" value="" /></view>
			<button class="confirm" form-type="submit" type="primary">确认修改</button>
		</form>
	</view>
</template>

<script>
	
import apiservice from '../../static/js/request.js';
export default {
	data() {
		return {
			phone: ''
		};
	},
	methods: {
		submit: function(e) {
			var formdata = e.detail.value;
			var info = JSON.stringify(e.detail.value);
			let opts = {
				url: '/login/updatePhone',
				method: 'GET'
			};
			let params = {
				phone: e.detail.value.oldphone,
				newtelephone: e.detail.value.newphone,
			};
			apiservice.httpRequest(opts, params).then(
				res => {
					console.log(res)
					if (res.data.flag === true) {
						uni.showToast({
							title: '修改成功',
						});
						uni.setStorageSync('phone', JSON.stringify(e.detail.value.newphone));
						uni.navigateBack({
						    delta: 1
						});
					} else {
						uni.showModal({
							content: '此用户不是会员，请重新输入旧手机号',
							showCancel: false
						});
					}
				},
				error => {
					console.log(error);
				}
			);
		}
	},
	onLoad() {
		if (uni.getStorageSync('phone')) {
			const formParam = JSON.parse(uni.getStorageSync('phone'));
			console.log(formParam)
			this.phone = formParam;
		}	
	}
};
</script>

<style lang="scss">
page {
	background-color: #efeff4;
}
.phone-content {
	width: 100%;
	padding: 30rpx 20rpx;
}
.title {
	margin-bottom: 20rpx;
	font-size: 34rpx;
}
.phone {
	height: 80rpx;
	line-height: 80rpx;
	padding: 0 20rpx;
	margin-bottom: 30rpx;
	border-radius: 8rpx;
	background-color: #fff;
	border: 1rpx solid #8F8F94;
}
.phone-input {
	height: 80rpx;
	line-height: 80rpx;
}
.confirm {
	margin-top: 100rpx;
}
</style>
