<template>
	<view class="content">
		<!-- <view class="btn-row">
			<button v-if="!hasLogin" type="primary" class="primary" @tap="bindLogin">登录</button>
			<button v-if="hasLogin" type="default" @tap="bindLogout">退出登录</button>
		</view> -->
		<view class="user-message clearfix" @click="toEdit">
			<view class="user-image pull-left"></view>
			<view class="user-name pull-left">
				<view class="name">{{ name }}</view>
				<view class="phone">{{ phone }}</view>
			</view>
			<view class="a-tips pull-right">>></view>
		</view>
		<view class="message-model">
			<navigator class="user-info clearfix" url="../edit-info/edit-info">
				<view class="edit-info pull-left">个人信息</view>
				<view class="mack-tip pull-right">>></view>
			</navigator>
			<navigator class="user-info clearfix" url="../done-list/done-list">
				<view class="edit-info pull-left">我的预约</view>
				<view class="mack-tip pull-right">>></view>
			</navigator>
		</view>
	</view>
</template>

<script>
import { mapState, mapMutations } from 'vuex';

import apiservice from '../../static/js/request.js';
export default {
	data() {
		return {
			name: '',
			phone: ''
		};
	},
	computed: {
		...mapState(['hasLogin', 'forcedLogin'])
	},
	methods: {
		...mapMutations(['logout']),
		bindLogin() {
			uni.navigateTo({
				url: '../login/login'
			});
		},
		bindLogout() {
			this.logout();
			/**
			 * 如果需要强制登录跳转回登录页面
			 */
			if (this.forcedLogin) {
				uni.reLaunch({
					url: '../login/login'
				});
			}
		},
		toEdit() {
			uni.navigateTo({
				url: '../edit-user/edit-user'
			});
		}
	},
	onLoad() {
		if (!this.hasLogin) {
			uni.showModal({
				title: '未登录',
				content: '您未登录，需要登录后才能继续',
				showCancel: false,
				success: res => {
					if (res.confirm) {
						if (this.forcedLogin) {
							uni.reLaunch({
								url: '../login/login'
							});
						} else {
							uni.navigateTo({
								url: '../login/login'
							});
						}
					}
				}
			});
		}
		if (this.hasLogin) {
			if (uni.getStorageSync('phone')) {
				const formParam = JSON.parse(uni.getStorageSync('phone'));
				console.log(formParam);
				this.phone = formParam;
			}
			if (uni.getStorageSync('yuyueinfo')) {
				const formParam = JSON.parse(uni.getStorageSync('yuyueinfo'));
				console.log(formParam);
				this.name = formParam.name;
			}
		}
	},
	onShow() {
		if (this.hasLogin) {
			if (uni.getStorageSync('phone')) {
				const formParam = JSON.parse(uni.getStorageSync('phone'));
				console.log(formParam);
				this.phone = formParam;
			}
			if (uni.getStorageSync('yuyueinfo')) {
				const formParam = JSON.parse(uni.getStorageSync('yuyueinfo'));
				console.log(formParam);
				console.log(formParam)
				this.name = formParam.name;
			}
		}
	}
};
</script>

<style lang="scss">
page {
	background-color: #efeff4;
}

.content {
	// width: 100%;
}

.user-message {
	/* height: 400rpx; */
	padding: 30rpx 40rpx;
	margin-bottom: 30rpx;
	background-color: #ffffff;
	border-radius: 8rpx;
}

.user-image {
	width: 120rpx;
	height: 120rpx;
	background-image: url(../../static/img/user-act.png);
	background-repeat: no-repeat;
	background-size: contain;
	border-radius: 50%;
}

.user-name {
	margin-left: 20rpx;

	.name {
		padding: 10rpx 0;
		font-size: 40rpx;
		font-weight: bold;
	}

	.phone {
		font-size: 34rpx;
	}
}

.a-tips {
	line-height: 120rpx;
}

.message-model {
	background-color: #fff;
	border-radius: 8rpx;
}

.user-info {
	padding: 20rpx 40rpx;
	border-bottom: 1rpx solid #dddddd;
}

.edit-info {
	font-size: 34rpx;
}

.mack-tip {
	line-height: 45rpx;
}
</style>
