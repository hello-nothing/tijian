<template>
	<view class="phone-content">
		<form @submit="submit">
			<view class="title">预约人姓名：</view>
			<view class="phone"><input v-model="formParam.name" class="phone-input" name="name" maxlength="13" type="text" value="" /></view>
			<view class="title">预约人年龄：</view>
			<view class="phone"><input v-model="formParam.age" class="phone-input" name="age" maxlength="3" type="number" value="" /></view>
			<view class="title">预约人性别：</view>
			<view class="phone">
				<radio-group name="sex">
					<label>
						<radio value="0" />
						<text>男</text>
					</label>
					<label class="sex-tip">
						<radio value="1" />
						<text>女</text>
					</label>
				</radio-group>
			</view>
			<view class="title">预约人手机号：</view>
			<view class="phone"><input disabled="disabled" v-model="phoneNumber" class="phone-input" name="phoneNumber" maxlength="13" type="text" value="" /></view>
			<view class="title">预约人身份证号：</view>
			<view class="phone"><input v-model="formParam.idcard" class="phone-input" name="idcard" maxlength="30" type="number" value="" /></view>
			<view class="title">婚否：</view>
			<view class="phone">
				<radio-group name="merry">
					<label>
						<radio value="hadMerry" />
						<text>已婚</text>
					</label>
					<label class="sex-tip">
						<radio value="noMerry" />
						<text>未婚</text>
					</label>
				</radio-group>
			</view>
			<view class="title">预约日期：</view>
			<!-- <view class="calender-model"><uni-calendar :insert="true" :lunar="true"  @change="change"></uni-calendar></view> -->
			<view class="phone">
				<picker name="date" mode="date" :value="date" :start="startDate" :end="endDate" @change="bindDateChange">
					<view class="uni-input">{{ date }}</view>
				</picker>
			</view>
			<button class="confirm" form-type="submit" type="primary">确认预约</button>
		</form>
	</view>
</template>

<script>
import apiservice from '../../static/js/request.js';
function getDate(type) {
	const date = new Date();

	let year = date.getFullYear();
	let month = date.getMonth() + 1;
	let day = date.getDate();

	if (type === 'start') {
		year = year - 60;
	} else if (type === 'end') {
		year = year + 2;
	}
	month = month > 9 ? month : '0' + month;
	day = day > 9 ? day : '0' + day;

	return `${year}-${month}-${day}`;
}
export default {
	data() {
		const currentDate = this.getDate({
			format: true
		});
		return {
			// date: currentDate,
			id: '',
			formParam: {
				name: '',
				age: '',
				// phoneNumber: '',
				idcard: ''
			},
			date: getDate({
				format: true
			}),
			startDate: getDate('start'),
			endDate: getDate('end'),
			phoneNumber: ''
		};
	},
	computed: {
		// startDate() {
		// 	return this.getDate('start');
		// },
		// endDate() {
		// 	return this.getDate('end');
		// }
	},
	components: {},
	methods: {
		bindDateChange: function(e) {
			this.date = e.target.value;
		},
		submit: function(e) {
			console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value));
			var formdata = e.detail.value;
			var info = JSON.stringify(e.detail.value);
			console.log(formdata);
			console.log(formdata);
			let opts = {
				url: '/order/submit',
				method: 'POST'
			};
			let params = {
				username: formdata.name,
				age: formdata.age,
				card: formdata.idcard,
				setmealId: this.id,
				orderDate: this.date,
				telephone: this.phoneNumber,
				// memberId: '',
				sex: formdata.sex,
				merry: formdata.merry
				
			};
			// const param = JSON.stringify(params)
			console.log('参数',params)
			apiservice.httpRequest(opts, params).then(
				res => {
					console.log(res);
					if (res.data.flag === false) {
						uni.showModal({
							title: '预约失败',
							content: '预约失败，请重新尝试！',
							showCancel: false
						});
					} else {
						uni.setStorageSync('listinfo', JSON.stringify(this.id));
						uni.navigateTo({
							url: '../done-list/done-list?id=' + this.id
						});
					}
				},
				error => {
					console.log(error);
				}
			);
		},
		change(e) {
			console.log(e);
		},
		getDate(type) {
			const date = new Date();
			let year = date.getFullYear();
			let month = date.getMonth() + 1;
			let day = date.getDate();

			if (type === 'start') {
				year = year - 60;
			} else if (type === 'end') {
				year = year + 2;
			}
			month = month > 9 ? month : '0' + month;
			day = day > 9 ? day : '0' + day;
			return `${year}-${month}-${day}`;
		},
		bindDateChange(e) {
			this.date = e.target.value;
		}
	},
	onLoad(option) {
		console.log(option);
		this.id = option.id;
		// if (uni.getStorageSync('yuyueinfo')) {
		// 	const formParam = JSON.parse(uni.getStorageSync('yuyueinfo'));
		// 	// this.userPhone = formParam.phone;
		// 	console.log(formParam);
		// 	this.formParam = formParam;
		// }
		if (uni.getStorageSync('phone')) {
			const formParam = JSON.parse(uni.getStorageSync('phone'));
			console.log(formParam)
			this.phoneNumber = formParam;
		}
	}
};
</script>

<style>
/* @import './static/common/uni.css'; */
page {
	/* height: 100%; */
	background-color: #efeff4;
}
.phone-content {
	position: relative;
	/* width: 100%; */
	height: 100%;
	padding: 30rpx 20rpx;
	padding-bottom: 100rpx;
}
.title {
	margin-bottom: 20rpx;
	font-size: 34rpx;
}
.phone {
	height: 80rpx;
	line-height: 80rpx;
	padding: 0 20rpx;
	margin-bottom: 30rpx;
	border-radius: 8rpx;
	background-color: #fff;
	border: 1rpx solid #8f8f94;
}
.phone-input {
	height: 80rpx;
	line-height: 80rpx;
}
.confirm {
	position: fixed;
	bottom: 0;
	width: calc(100% - 40rpx);
	margin-top: 100rpx;
}
.sex-tip {
	margin-left: 100rpx;
}
.uni-list {
	height: 200rpx;
}
.uni-list-cell-left {
	padding-right: 30rpx;
}
</style>
