<template>
	<view class="done-list">
		<view class="list-model" v-for="(item, index) in doneList" :key="index">
			<view class="people">体检人：{{ item.username }}</view>
			<view class="people">体检套餐：{{ item.name }}</view>
			<view class="people">体检日期：{{ item.orderDate }}</view>
			<view class="people">预约类型：{{ item.orderType }}</view>
			<view class="people">预约状态：{{ item.orderStatus }}</view>
		</view>
	</view>
</template>

<script>
	import apiservice from '../../static/js/request.js';
	export default {
		data() {
			return {
				doneList: [{
						peopleName: '张三',
						name: '套餐一',
						date: '2020年12月1号',
						type: '类型一'
					},
					{
						peopleName: '张三',
						name: '套餐一',
						date: '2020年12月1号',
						type: '类型一'
					},
					{
						peopleName: '张三',
						name: '套餐一',
						date: '2020年12月1号',
						type: '类型一'
					},
					{
						peopleName: '张三',
						name: '套餐一',
						date: '2020年12月1号',
						type: '类型一'
					},
					{
						peopleName: '张三',
						name: '套餐一',
						date: '2020年12月1号',
						type: '类型一'
					}
				],
				phoneNumber: ''
			};
		},
		methods: {
			
			getList: function() {
				let opts = {
					url: '/order/orderList',
					method: 'get'
				};
				let params = {
					phone: this.phoneNumber
				};
				apiservice.httpRequest(opts, params).then(
					res => {
						console.log('我的预约列表数据', res);
						console.log(res.data);
						this.doneList = res.data;
				
					},
					error => {
						console.log(error);
					}
				);
			}
		},
		onLoad: function(option) {
			//option为object类型，会序列化上个页面传递的参数
			console.log(option); //打印出上个页面传递的参数。
			if (uni.getStorageSync('phone')) {
				const formParam = JSON.parse(uni.getStorageSync('phone'));
				this.phoneNumber = formParam;
				console.log(this.phoneNumber)
				this.getList()
			}
		},
	};
</script>

<style lang="scss">
	page {
		background-color: #efeff4;
	}

	.done-list {
		// width: 100%;
		padding: 20rpx;
		background-color: #efeff4;
	}

	.list-model {
		padding: 20rpx;
		margin-bottom: 30rpx;
		background-color: #fff;
		border-radius: 8rpx;
	}
</style>
