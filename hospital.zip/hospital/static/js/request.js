// import globalApi from '../../main.js'
const baseUrl = 'http://121.36.173.144:19865';
const httpRequest = (opts, data) => {
	let httpDefaultOpts = {
		url: baseUrl + opts.url,
		data: data,
		method: opts.method,
		dataType: 'json',
	}
	let promise = new Promise(function(resolve, reject) {
		uni.showLoading({
			title: '加载中'
		});
		uni.request(httpDefaultOpts).then(
			(res) => {
				resolve(res[1])
				uni.hideLoading();
			}
		).catch(
			(response) => {
				reject(response)
				uni.showLoading({
					title: '请求出错！'
				});
			}
		)
	})
	return promise
}

// function get(url, data, success, fail) {
// 	uni.request({
// 		url: globalApi.baseUrl + url,
// 		method: 'GET',
// 		data: data,
// 		success: function(result) {
// 			console.log(result)
// 		},
// 		fail: fail,
// 		dataType: 'json'

// 	})
// }

// function post(url, data, success, fail) {
// 	uni.request({
// 		url: globalApi.baseUrl + url,
// 		method: 'POST',
// 		data: data,
// 		success: function(result) {
// 			console.log(result)
// 		},
// 		fail: fail,
// 		dataType: 'json'

// 	})
// }
export default {
	httpRequest,

	// getdisputeType(opts) {
	// 	const url = '/api/apiMediatorService/searchMediatorList';
	// 	return this.get(opts, data);
	// },
	// 获取纠纷类型
	// getdisputeType: (data, success, fail) => {
	// 	get('/service/rest/mediation.Stb/6d936e2d7ca94bf8a887619f3022ff4d/getCategory', success, fail)
	// },
	// // 获取案发区域
	// getcaseArea: (data, success, fail) => {
	// 	get('/service/rest/tk.Zone/086/tree', success, fail)
	// },
	// // 调解队伍列表
	// getgetPeopleList: (data, success, fail) => {
	// 	get('/api/apiMediatorService/searchMediatorList', data, success, fail)
	// },
	// // 调解员详情
	// getgetPeopleList: (data, success, fail) => {
	// 	get('/api/apiMediatorService/getMediatorInfo', data, success, fail)
	// },
	// // 专题详情
	// getgetPeopleList: (data, success, fail) => {
	// 	get('/api/helpOutService/getRepeatProgrammeInfo', data, success, fail)
	// },
}
